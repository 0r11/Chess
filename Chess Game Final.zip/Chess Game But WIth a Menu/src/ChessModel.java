/**This serves to allow us to call all of our functions*/
//This allows for dynamic logic so that we can implement an AI class that doesn't require a player to click on the square.
public class ChessModel {
    private boolean isWhite;
    private Board board;
    private GUI gui;

    /**For making an instance of the game*/
    public static void main(String[] args) { //Creates instance of a game
        ChessModel c = new ChessModel();
        c.startMatch();

    }

    /**Starts the match*/
    private void startMatch()  {
        //Initializing various classes
        board = new Board();
        gui = new GUI();
        board.initialize();
        isWhite = true;
        board.level = 0;
        if(gui.drawMenu()){againstAi();} else {againstPlayer();}
    }

    /**A game where the player plays against an AI*/
    private void againstAi(){
        isWhite = true;
        AI ai = new AI(board, gui);
        if(ai.isWhite()){
            System.out.println("Playing against white AI");
        } else {
            System.out.println("Playing against black AI");
        }
        while(true){
            /*If the Ai is playing */
            gui.drawBoard(board);
            if (ai.isWhite == isWhite) {
                ai.takeTurn();
            } else {
                gui.handleMouseClick(isWhite, board);
            }
            if(gameOver()){break;}
            if (isInDraw()) {break;}
            isWhite = !isWhite;
//            System.gc(); //To help make it take less memory
        }
    }

    /**A game where the player plays against another player*/
    private void againstPlayer(){
        isWhite = true;
        while(true){
            gui.drawBoard(board);
            gui.handleMouseClick(isWhite, board);
            if (gameOver()) {break;}
            if (isInDraw()) {break;}
            isWhite = !isWhite;
            System.gc(); //To help make it take less memory
        }
    }

    /**Handles if one player wins*/
    private boolean gameOver(){
        if(board.isInCheckmate(true) ) {
            gui.end(true);
            System.out.println("White wins");
            return true;
        } else if(board.isInCheckmate(false) ) {
            gui.end(false);
            System.out.println("Black wins");
            return true;
        }

        return false;
    }

    /**Handles if the board is drawn*/
    private boolean isInDraw(){
        if(board.repetition() || board.onlyKings() || board.isStalemate(false) || board.isStalemate(true)){ //Only two checks are to see if the board has 3-fold repetition or if it's only kings
            //There are rarer drawn states that aren't implemented, however they are really rare.
            System.out.println("Draw");
            gui.drawEnd();
            return true;
        }
        return false;
    }
}