import java.awt.*;
import java.util.ArrayList;

public class GUI {

    private static Board.Piece piece;
    public double whitePieces = 0; //Number
    public double blackPieces = 0;
    public static String[] whiteImages;
    public static String[] blackImages;

    /**Defining images*/
    public GUI() {
        this.piece = piece;
        whiteImages = new String[]{"whiteRook copy.png", "whiteBishop copy.png", "whiteQueen copy.png",
                "whiteHorse copy.png", "WhitePawn copy.png", "WhiteKing copy.png"};
        blackImages = new String[]{"blackRook copy.png", "blackBishop copy.png", "blackQueen copy.png",
                "blackHorse copy.png", "blackPawn copy.png", "blackKing copy.png"};
    }

    /**Draws the menu*/
    public boolean drawMenu() {
        StdDraw.setXscale(-.5, 7.5);
        StdDraw.setYscale(-.5, 7.5);

        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 8; y++) {
                if ((x + y) % 2 == 0) {
                    StdDraw.setPenColor(Color.darkGray);
                    StdDraw.filledSquare(x, y, .5);
                } else {
                    StdDraw.setPenColor(Color.lightGray);
                    StdDraw.filledSquare(x, y, .5);
                }

            }
        }

        StdDraw.setPenColor(Color.pink);
        StdDraw.setPenRadius(0.025);
        StdDraw.square(1.75, 4, 1.4);
        StdDraw.square(5.25, 4, 1.4);
        StdDraw.picture(1.75, 4, "PvP copy.jpeg");
        StdDraw.picture(5.25, 4, "PvC copy.jpeg");

        while (true){
            while (!StdDraw.isMousePressed()) {
                // Wait for mouse press
            }
            double x = Math.round(StdDraw.mouseX());
            double y = Math.round(StdDraw.mouseY());

            while (StdDraw.isMousePressed()) {
                // Wait for mouse release
            }

            if ((x > .25 && x < 3.25) && (y > 2.5 && y < 5.5)) {
                StdDraw.clear();
                return false; // 1 player
            } else if (((x > 3.75 && x < 6.75) && (y > 2.5 && y < 5.5))) {
                StdDraw.clear();
                return true; //2 player
            }
        }
    }

    /**Draws the board*/
    public void drawBoard(Board board) {
        StdDraw.setXscale(-.5, 7.5);
        StdDraw.setYscale(-1, 8);

        //draws checkered board
        for (int x = 0; x < 8; x++) {
            for (int y = 0; y < 8; y++) {
                if ((x + y) % 2 == 0) {
                    StdDraw.setPenColor(Color.darkGray);
                    StdDraw.filledSquare(x, y, .5);
                } else {
                    StdDraw.setPenColor(Color.lightGray);
                    StdDraw.filledSquare(x, y, .5);
                }

                //initializes piece position and displays them on board
                if (board.BoardGetPiece(x, y) != null) {
                    if (board.BoardGetPiece(x, y).isWhite()) {
                        StdDraw.picture(x, y, whiteImages[board.BoardGetPiece(x, y).getPiece()]);
                    } else {
                        StdDraw.picture(x, y, blackImages[board.BoardGetPiece(x, y).getPiece()]);
                    }
                }
            }
        }
    }

    //(Mouse press code adapted from Domineering Lab)
    /**Handles the mouse click*/
    public void handleMouseClick(boolean isWhite, Board board) {
        while (true) {
            while (!StdDraw.isMousePressed()) {
                // Wait for mouse press
            }
            double x = Math.round(StdDraw.mouseX());
            double y = Math.round(StdDraw.mouseY());

            while (StdDraw.isMousePressed()) {
                // Wait for mouse release
            }

            int a = (int) x;
            int b = (int) y;

            //Marks moves as invalid
            if (board.BoardGetPiece(a, b) == null) {
                drawBoard(board);
                StdDraw.setPenColor(Color.RED);
                StdDraw.setFont(new Font("Times new Roman", 30, 25));
                StdDraw.text(3.5, 4, "Click on a piece");
                continue;
            } else if (board.BoardGetPiece(a, b).isWhite() != isWhite) { //Makes it so you can't select other color's piece
                continue;
            }

            //when user selects piece it gets highlighted pink
            else if (board.BoardGetPiece(a, b).isWhite() == isWhite) {
                drawBoard(board);
                StdDraw.setPenColor(Color.pink);
                StdDraw.setPenRadius(0.01);
                StdDraw.square(a, b, .45);
                drawDot(board.BoardGetPiece(a,b), board, a, b);
            }

            //after piece is selected, wait for mouse press of desjred location (Mouse press code adapted from Domineering Lab)
            if (board.BoardGetPiece(a, b) != null) {
                while (!StdDraw.isMousePressed()) {
                    // Wait for mouse press
                }
                double x1 = Math.round(StdDraw.mouseX());
                double y1 = Math.round(StdDraw.mouseY());

                while (StdDraw.isMousePressed()) {
                    // Wait for mouse release
                }


                int a1 = (int) x1;
                int b1 = (int) y1;
//                    if(board.getPiece(a,b) == null){System.out.println(a + b);continue;}
                //If move is legal it places piece, if else it runs the method again and allows the user to make another move
                if (board.BoardGetPiece(a, b).isLegal(a1, b1, isWhite) && !board.willBeInCheck(a,b,a1,b1)) {
                    if (board.BoardGetPiece(a1, b1) != null) { //captured Black Piece
                        captured(board.BoardGetPiece(a1, b1));
                        board.BoardGetPiece(a, b).movePiece(a1, b1);

                    } else {
                        board.BoardGetPiece(a, b).movePiece(a1, b1);
                    }

                    drawBoard(board);
                    StdAudio.play("ChessAudio.wav");
                    return;
                }
                drawBoard(board);

            }
        }
    }

    /**Uses possibleMoves method from Piece class and takes the coordinates of those moves and places a dot at each*/
    public void drawDot(Board.Piece p, Board board, int a, int b){
        ArrayList<Integer> circleX = new ArrayList<>();
        ArrayList<Integer> circleY = new ArrayList<>();

        ArrayList<Integer[]> dots = board.BoardGetPiece(a, b).pieceCanMove();
        for (int i = 0; i < dots.size(); i++) {
            Integer[] num = dots.get(i);

            for (int j = 0; j < num.length; j++) {
                int value = num[j];
                if (j % 2 == 0) {
                    circleX.add(value);
                } else {
                    circleY.add(value);
                }
            }
        }

        for (int n = 0; n < circleX.size(); n++) {
            StdDraw.setPenColor(Color.GRAY);
            if (board.BoardGetPiece(circleX.get(n), circleY.get(n)) == null) {
                StdDraw.filledCircle(circleX.get(n), circleY.get(n), .2);
            } else {
                StdDraw.circle(circleX.get(n), circleY.get(n), .4);
            }
        }
    }

    /**Adds captured pieces to the top/bottom of the board*/
    public void captured(Board.Piece p){
        if(p.isWhite()){
            StdDraw.picture(whitePieces / 2, 7.75, whiteImages[p.getPiece()],0.5,0.5);
            whitePieces += 1;
        } else {
            StdDraw.picture(blackPieces / 2, -.75, blackImages[p.getPiece()],0.5,0.5);
            blackPieces += 1;
        }
    }

    /**Writes who wins on the screen*/
    public void end(boolean isWhite){
        StdDraw.setPenColor(StdDraw.PINK); //Makes a pink rectangle
        StdDraw.filledRectangle(3.5,3.5,1.5,0.5);
        StdDraw.setPenColor(StdDraw.WHITE); //and a smaller white rectangle on top
        StdDraw.filledRectangle(3.5,3.5,1.4,0.4);
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.setFont(new Font("Times new Roman", 30, 30));
        if(!isWhite){
            StdDraw.text(3.5,3.5,"Black wins!!!"); //Says who wins
        } else {
            StdDraw.text(3.5,3.5,"White wins!!!");
        }
    }

    /**For when the game ends with a draw*/
    public void drawEnd(){
        StdDraw.setPenColor(StdDraw.PINK); //Makes a pink rectangle
        StdDraw.filledRectangle(3.5,3.5,.8,0.5);
        StdDraw.setPenColor(StdDraw.WHITE); //and a smaller white rectangle on top
        StdDraw.filledRectangle(3.5,3.5,.7,0.4);
        StdDraw.setPenColor(StdDraw.BLACK);
        StdDraw.setFont(new Font("Times new Roman", 30, 30));
        StdDraw.text(3.5,3.5,"Draw"); //displays the drawing text

    }
}

