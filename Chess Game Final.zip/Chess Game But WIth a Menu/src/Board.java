import java.util.ArrayList;

/**A class which contains a board which contains all the pieces*/
public class Board {

    //Defining the instance variables
    private final Piece[][] board;
    public static final ArrayList<Board> game = new ArrayList<>(); //list of all the boards
    public int level; //Used to indicate the recursion level to avoid infinite recursion

    /**makes a board*/
    public Board(){board = new Piece[8][8];}

    /**Gets the piece*/
    public Piece BoardGetPiece(int x, int y){
        if(x < 0 || x > 7 || y < 0 || y > 7){return null;}
        return board[x][y];
    }

    /**Sets the piece*/
    public void setPiece( int x, int y, Piece p){
        board[x][y] = p;
    }

    /**Evaluates based on what pieces each player has*/
    public double evaluate(boolean isWhite){
        final double[] pieceValues = {5,3,9,3,1,1000};
        //Source https://www.chess.com/forum/view/chess-variants/relative-values-of-squares-files-ranks-and-layers-of-the-chessboard
        final double[] positionValues = {.1, .123, .137, .139, .139, .137, .123, .1};
        int score = 0;
        for(Piece[] t: board){
            for(Piece p: t){
                if(p != null){
                    if(p.isWhite() == isWhite){
                        score += pieceValues[p.getPiece()] + positionValues[p.getPosition()[0]] + positionValues[p.getPosition()[1]];
                    } else {
                        score -= pieceValues[p.getPiece()] - positionValues[p.getPosition()[0]] - positionValues[p.getPosition()[1]];
                    }
                }
            }
        }
        return score;
    }

    /** Copies this board to passed board */
    public void copy(Board b){
        for(int x = 0; x < board.length; x++){
            for(int y = 0; y < board[x].length; y++){
                if(board[x][y] != null) {
                    b.setPiece(x, y, board[x][y].copy(b));
                }
            }
        }
    }

    /** Returns true if you're in check */
    public boolean isCheck(boolean isWhite){
        for (Piece[] column : board) {
            for (Piece piece : column) { //For each piece
                if (piece != null) {
                    if (piece.isWhite() == isWhite) { //That's the color
                        for (Integer[] i : piece.pieceCanMove()) { //Look at each possible move
//                            System.out.println(x + " " +y + "  " + i[0] + " " + i[1]);
                            if (board[i[0]][i[1]] != null) {
                                if (board[i[0]][i[1]].getPiece() == 5) { //If there's a king on the square
                                    return true;
                                }
                            }
                        }
                    }
                }
            }
        }
        return false;
    }

    /**Returns true if the piece will be in check if it moves from the first set*/
    public boolean willBeInCheck(int x, int y, int x1, int y1){
        Board b = new Board();
        this.copy(b);
        //Doesn't go past a depth of 2 moves ahead for checking
        b.level = this.level + 1;
        if(b.level >= 2){return false;} //Base Case
        b.BoardGetPiece(x,y).movePiece(x1,y1);
        boolean result = b.isCheck(!b.BoardGetPiece(x1,y1).isWhite());
        b = null;
        return result; //recursion otherwise
    }

    /**Returns true if its in checkmate*/
    public boolean isInCheckmate(boolean isWhite){
        if(!isCheck(isWhite)){ return false;}
        for(int x = 0; x < board.length; x++) {
            for (int y = 0; y < board[x].length; y++) { //For each piece
                if(board[x][y] != null){
                    if(board[x][y].isWhite() == !isWhite){ //That's the color
                        for(Integer[] i: board[x][y].pieceCanMove()){ //Look at each possible move
                            if(!willBeInCheck(x,y,i[0],i[1])){
                                return false;
                            }
                        }
                    }
                }
            }
        }
        System.out.println("Check Mate");
        return true;
    }

    /** Returns true if in stalemate. (same code as isInCheckmate but not currently in check*/
    public boolean isStalemate(boolean isWhite){
        if(isCheck(isWhite)){ return false;}
        for(int x = 0; x < board.length; x++) {
            for (int y = 0; y < board[x].length; y++) { //For each piece
                if(board[x][y] != null){
                    if(board[x][y].isWhite() == !isWhite){ //That's the color
                        for(Integer[] i: board[x][y].pieceCanMove()){ //Look at each possible move
                            if(!willBeInCheck(x,y,i[0],i[1])){
                                return false;
                            }
                        }
                    }
                }
            }
        }
        System.out.println("Stale Mate");
        return true;
    }

    /** Puts all pieces in their initial positions */
    public void initialize(){ // {Rook, bishop, queen, knight, pawn, king}
        //public Piece(int piece, int x, int y, boolean isWhite, Board board)

        //White
        board[0][0] = new Piece(0, 0, 0, true, this); //Going left to right  //Rook
        board[1][0] = new Piece(3, 1, 0, true, this); // Knight
        board[2][0] = new Piece(1, 2, 0, true, this); // Bishop
        board[3][0] = new Piece(2, 3, 0, true, this); // King
        board[4][0] = new Piece(5, 4, 0, true, this); // Queen
        board[5][0] = new Piece(1, 5, 0, true, this); // Bishop
        board[6][0] = new Piece(3, 6, 0, true, this); // Knight
        board[7][0] = new Piece(0, 7, 0, true, this); //Rook
        for(int i = 0; i < 8; i ++){
            board[i][1] = new Piece(4, i, 1, true, this); //Pawns
        }

        //Black
        board[0][7] = new Piece(0, 0, 7, false, this); //Going left to right  //Rook
        board[1][7] = new Piece(3, 1, 7, false, this); // Knight
        board[2][7] = new Piece(1, 2, 7, false, this); // Bishop
        board[3][7] = new Piece(2, 3, 7, false, this); // King
        board[4][7] = new Piece(5, 4, 7, false, this); // Queen
        board[5][7] = new Piece(1, 5, 7, false, this); // Bishop
        board[6][7] = new Piece(3, 6, 7, false, this); // Knight
        board[7][7] = new Piece(0, 7, 7, false, this); //Rook
        for(int i = 0; i < 8; i ++) {
            board[i][6] = new Piece(4, i, 6, false, this); //Pawns
        }
    }

    /**Records the board state. Only called if it's the real board.*/
    public void store(){
        Board b = new Board();
        this.copy(b);
        game.add(b);
    }

    /**Checks for 3-fold repetition*/
    public boolean repetition(){
        int count = 0;
        for(Board board: game){ //Sees how many previous board states match the most recent move
            if(board.isSameBoard(game.get(game.size() - 1))){
                count ++;
            }
        }
//        System.out.println("Game length: " + game.size());
//        System.out.println("Repetition: " + count);
        return count == 3; //If the same board has happened 3 times it will mark it as a draw
        //Technically this is not the correct check
        //But its close enough, so I don't really care
    }

    /**Sees if its the same board*/
    private boolean isSameBoard(Board b){
        boolean result = true;
        for(int x = 0; x < 8; x++){
            for(int y = 0; y < 8; y ++){
                if((board[x][y] == null) && (b.BoardGetPiece(x,y) != null)) {
                    result = false;
                } else if((board[x][y] != null) && (b.BoardGetPiece(x,y) == null)){
                    result = false;
                } else if((board[x][y] == null) && (b.BoardGetPiece(x,y) == null)){
                } else if(board[x][y].getPiece() != b.BoardGetPiece(x,y).getPiece()){
                    result = false;
                }
            }
        }
        return result;
    }

    /**Sees if the board only contains kings*/
    public boolean onlyKings(){
        for(Piece[] col: board){
            for(Piece p: col){
                if(p != null) {
                    if (p.getPiece() != 5) { //Looks for any piece that's not a king
                        return false;
                    }
                }
            }
        }
        System.out.println("Only kings");
        return true;
    }

    /*All the pieces... NOW IN THE BOARD CLASS*/
    /**The pieces basically dictate how the different pieces on the board move*/
    public class Piece {
        //Initialize variables
        private int x;
        private int y;
        private int thisPiece;
        private final boolean isWhite;
        public boolean pieceHasMoved = false;
        private final Board board;
        /*For some reason, it really doesn't like it if we replace the calling of 'board' with 'Board.this'
        I think it has to do with static variables, but it freaks out and does a stack overflow error,
        because our counter for how many levels deep is no longer able to deal with recursion.
        I think that I could rewrite it to do recursion iteratively, but I don't really think its worth it.
        This is the easiest workaround, and it also makes the code easier to read
        I'm sorry that I can't figure out how to do it properly
        */

        /**Makes a new piece
         * @Param piece 0 = Rook; 1 = bishop; 2 = queen; 3 = knight; 4 = pawn; 5 = king
         * */
        public Piece(int piece, int x, int y, boolean isWhite, Board board){
            this.x = x;
            this.y = y;
            thisPiece = piece; // {rook, bishop, queen, knight, pawn, king}
            this.isWhite = isWhite;
            this.board = board;
        }

        /**Makes a copy of the piece*/
        public Piece copy(Board b){
            Piece p = new Piece(thisPiece, x, y, isWhite, b);
            p.pieceHasMoved = pieceHasMoved;
            return p;
        }

        /**Sees if the piece has moved yet*/
        public boolean hasMoved(){return pieceHasMoved;}

        /**Returns true if the piece is white*/
        public boolean isWhite(){return isWhite;}

        /**Gets the piece integer value index thing*/
        public int getPiece(){return thisPiece;}

        /**Returns the position*/
        public int[] getPosition(){
            return new int[]{x,y};
        }

        /**Checks to see if the rook can move to a given square (Castling not yet implemented)*/
        private ArrayList<Integer[]> rookCanMove(){
            ArrayList<Integer[]> result = new ArrayList<>();
            int[][] directions = {{0,1},{0,-1},{1,0},{-1,0}}; //List of directions to go in
            for(int[] offset: directions) {
                for(int j = 1; j < 8; j ++){
                    Integer[] coords = {x + offset[0] * j, y + offset[1] * j};
                    if( (coords[0] < 8 && coords[0] > -1) && (coords[1] < 8 && coords[1] > -1)){
                        Piece p = board.BoardGetPiece(coords[0],coords[1]);
                        if (p == null) {
                            if(!board.willBeInCheck(x,y,coords[0],coords[1])) {
                                result.add(coords);
                            }
                        } else { //If there is a piece it can't hop over it
                            j = 8;
                            if (p.isWhite() != isWhite) {
                                if(!board.willBeInCheck(x,y,coords[0],coords[1])) {
                                    result.add(coords); //It can capture it though
                                }
                            }
                        }

                    }
                }
            }
            return result;
        }

        /**Checks to see if the bishop can move to a given square */
        private ArrayList<Integer[]> bishopCanMove(){
            ArrayList<Integer[]> result = new ArrayList<>();
            int[][] directions = {{1,1},{-1,-1},{1,-1},{-1,1}}; //List of directions to go in
            for(int[] offset: directions) {
                for(int j = 1; j < 8; j ++){
                    Integer[] coords = {x + offset[0] * j, y + offset[1] * j};
                    if( (coords[0] < 8 && coords[0] > -1) && (coords[1] < 8 && coords[1] > -1)){
                        Piece p = board.BoardGetPiece(coords[0], coords[1]);
                        if (p == null) {
                            if(!board.willBeInCheck(x,y,coords[0],coords[1])) {
                                result.add(coords);
                            }
                        } else {
                            j = 8;
                            if (p.isWhite() != isWhite) {
                                if(!board.willBeInCheck(x,y,coords[0],coords[1])) {
                                    result.add(coords);
                                }
                            }
                        }

                    }
                }
            }
            return result;
        }

        /**Checks to see if the knight can move to a given square */
        private ArrayList<Integer[]> knightCanMove(){
            ArrayList<Integer[]> result = new ArrayList<>();
            int[][] directions = {{1,2},{1 , -2},{-1,2},{-1, -2},{2,1},{2 , -1},{-2,1},{-2, -1}}; //List of directions to go in
            for(int[] offset: directions) { //Looks at all offsets
                Integer[] coords = {x + offset[0], y + offset[1]};
                if( (coords[0] < 8 && coords[0] > -1) && (coords[1] < 8 && coords[1] > -1)) {
                    Piece p = board.BoardGetPiece(coords[0], coords[1]);
                    if (p == null) {
                        if ((coords[0] < 8 && coords[0] > -1) && (coords[1] < 8 && coords[1] > -1)) {
                            if(!board.willBeInCheck(x,y,coords[0],coords[1])) {
                                result.add(coords);
                            }
                        }
                    } else {
                        if (p.isWhite() != isWhite) {
                            if( (coords[0] < 8 && coords[0] > -1) && (coords[1] < 8 && coords[1] > -1)){
                                if(!board.willBeInCheck(x,y,coords[0],coords[1])) {
                                    result.add(coords);
                                }
                            }
                        }
                    }
                }

            }
            return result;
        }

        /**Checks to see if the pawn can move to a given square (en passant not yet included)*/
        private ArrayList<Integer[]> pawnCanMove(){
            ArrayList<Integer[]> result = new ArrayList<>();
            if(isWhite){ //If white go forward
                if (board.BoardGetPiece(x, y + 1) == null) {
                    Integer[] t = {x, y + 1};
                    if(!board.willBeInCheck(x,y,t[0],t[1])) {
                        result.add(t);
                    }
                    if (!pieceHasMoved) { //Can move double if it hasn't moved
                        if (board.BoardGetPiece(x, y + 2) == null) {
                            Integer[] t2 = {x, y + 2};
                            if(!board.willBeInCheck(x,y,t2[0],t2[1])) {
                                result.add(t2);
                            }
                        }
                    }
                }

                if(x > 0) {
                    if (board.BoardGetPiece(x - 1, y + 1) != null) { //Attack opponent diagonally
                        if (!board.BoardGetPiece(x - 1, y + 1).isWhite()) {
                            Integer[] t = {x - 1, y + 1};
                            if(!board.willBeInCheck(x,y,t[0],t[1])) {
                                result.add(t);
                            }
                        }
                    }
                }
                if(x < 7) {
                    if (board.BoardGetPiece(x + 1, y + 1) != null) {
                        if (!board.BoardGetPiece(x + 1, y + 1).isWhite()) {
                            Integer[] t = {x + 1, y + 1};
                            if(!board.willBeInCheck(x,y,t[0],t[1])) {
                                result.add(t);
                            }
                        }
                    }
                }
            } else { //If black go back
                if(board.BoardGetPiece(x,y - 1) == null){
                    Integer[] t = {x, y - 1};
                    if(!board.willBeInCheck(x,y,t[0],t[1])) {
                        result.add(t);
                    }
                    if(!pieceHasMoved) {
                        if (board.BoardGetPiece(x, y - 2) == null) {
                            Integer[] t2 = {x, y - 2};
                            if(!board.willBeInCheck(x,y,t2[0],t2[1])) {
                                result.add(t2);
                            }
                        }
                    }
                }
                if( x > 0) {
                    if (board.BoardGetPiece(x - 1, y - 1) != null) {
                        if (board.BoardGetPiece(x - 1, y - 1).isWhite()) {
                            Integer[] t = {x - 1, y - 1};
                            if(!board.willBeInCheck(x,y,t[0],t[1])) {
                                result.add(t);
                            }
                        }
                    }
                }
                if( x < 7) {
                    if (board.BoardGetPiece(x + 1, y - 1) != null) {
                        if (board.BoardGetPiece(x + 1, y - 1).isWhite()) {
                            Integer[] t = {x + 1, y - 1};
                            if(!board.willBeInCheck(x,y,t[0],t[1])) {
                                result.add(t);
                            }
                        }
                    }
                }
            }
            return result;
        }

        /**Checks to see if the knight can move to a given square */
        private ArrayList<Integer[]> kingCanMove(){
            ArrayList<Integer[]> result = new ArrayList<>();
            int[][] directions = {{1,1},{1 , -1},{-1,1},{-1,-1},{0,1},{0,-1},{-1,0},{1, 0}}; //List of directions to go in
            for(int[] offset: directions) {
                Integer[] coords = {x + offset[0], y + offset[1]};
                if( (coords[0] < 8 && coords[0] > -1) && (coords[1] < 8 && coords[1] > -1)){
                    Piece p = board.BoardGetPiece(coords[0],coords[1]);
                    if(p == null){
                        if(!board.willBeInCheck(x,y,coords[0],coords[1])) {
                            result.add(coords);
                        }
                    } else {
                        if(p.isWhite() != isWhite){
                            if(!board.willBeInCheck(x,y,coords[0],coords[1])) {
                                result.add(coords);
                            }
                        }
                    }
                }

            }
            //Castling
            if(!pieceHasMoved/* && !board.isCheck(isWhite)*/) { //If it checks for check, it goes into an infinite loop...
                if (board.BoardGetPiece(x - 4,y) != null){ //Checks to see if there is an unmoved piece in either of the rooks starting positions
                    if(!board.BoardGetPiece(x - 4, y).hasMoved()){
                        if(board.BoardGetPiece(x - 1, y) == null && board.BoardGetPiece(x - 2, y) == null && board.BoardGetPiece(x - 3, y) == null) { //If there's no pieces in the way
                            if(!board.willBeInCheck(x,y,x-2,y)) {
                                result.add(new Integer[]{x - 2, y});
                            }
                        }
                    }
                }
                if (board.BoardGetPiece(x + 3,y) != null){ //Same but for Queen's side
                    if(!board.BoardGetPiece(x + 3, y).hasMoved()){
                        if(board.BoardGetPiece(x + 1, y) == null && board.BoardGetPiece(x + 2, y) == null) {
                            if(!board.willBeInCheck(x,y,x+2,y)) {
                                result.add(new Integer[]{x + 2, y});
                            }
                        }
                    }
                }
            }
            return result;
        }

        /**Returns an ArrayList of coordinate pairs of all the places it can move*/
        public ArrayList<Integer[]> pieceCanMove(){
            if(thisPiece == 0){
                //Rook
                return rookCanMove();
            } else if( thisPiece == 1){
                //Bishop
                return bishopCanMove();
            } else if(thisPiece == 2){
                //Queen
                ArrayList<Integer[]> result = rookCanMove();
                ArrayList<Integer[]> result2 = bishopCanMove();
                result.addAll(result2);
                return result;
            } else if(thisPiece == 3){
                //Knight
                return knightCanMove();
            } else if(thisPiece == 4){
                //Pawn
                return pawnCanMove();
            } else if(thisPiece == 5){
                //King
                return kingCanMove();
            }
            return null;
        }


        /**Moves the piece (if it can move to that square)*/
        public void moveTo(int x1,int y1) {
            pieceHasMoved = true;
            board.setPiece(x1, y1, this);
            board.setPiece(x, y, null);
            x = x1;
            y = y1;
        }

        /**Moves the piece*/
        public void movePiece(int x1, int y1) {
            if (isLegal(x1, y1, isWhite)) {

                if (thisPiece == 5) { //Can castle if a king
                    if (x - x1 == 2) { //and moves two left
                        board.BoardGetPiece(x-4,y).moveTo(x-1,y);
                    } else if (x1 - x == 2) { //or two right
                        board.BoardGetPiece(x+3,y).moveTo(x+1,y);
                    }
                }

                moveTo(x1,y1);

                if(board.level == 0){ //If it's the real board // Make sure it references board, otherwise stores all possible board states
                    board.store();
                }

                //Pawn promotion
                if (thisPiece == 4 && ((isWhite && y1 >= 7) || (!isWhite && y1 <= 0))) {
                    thisPiece = 2; //Sets it to a queen automatically
                }
            }
        }

        /**Sees if its legal*/
        public boolean isLegal(int x1, int y1, boolean isWhite){
            if(this.isWhite != isWhite){ return false;}
            for(Integer[] move: pieceCanMove()){ //Looks to see if it's in the list of possible moves
                if( move[0] == x1 && move[1] == y1){
                    return true;
                }
            }
            return false;
        }
    }

}