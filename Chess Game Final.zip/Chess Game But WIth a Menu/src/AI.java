import java.awt.*;
import java.util.ArrayList;

/**And AI for playing against the player*/
public class AI {
    public boolean isWhite;
    //Needs a copy of the gui and board for reference
    Board board;
    GUI gui;

    public AI(Board board, GUI gui){
        this.isWhite = StdRandom.bernoulli(); //it chooses a random color
        this.board = board;
        this.gui = gui;
    }

    public boolean isWhite(){return isWhite;}

    /**A class for storing a move*/
    private class Move {
        public double score;
        public Board.Piece p;
        public int x;
        public int y;
        public int x1;
        public int y1;

        public Move(){}

        public void setMove(double score, Board.Piece p, int x, int y, int x1, int y1){
            this.score = score;
            this.p = p;
            this.x = x;
            this.y = y;
            this.x1 = x1;
            this.y1 = y1;
        }
    }

    /**Recursive polynomial time function for finding the best move*/
    public Move findBestMove(int depth, boolean isWhite, Board board){
        Move best = new Move();
        best.score = -10000; //The best score starts really bad
        for(int x = 0; x < 8; x ++){ //Goes through each piece
            for(int y = 0; y < 8; y++){
                if(board.BoardGetPiece(x,y) != null){ //Checks if there's a piece
                    Board.Piece p = board.BoardGetPiece(x,y);
                    if(p.isWhite() == isWhite){ //If its the color its supposed to be...
                        for(Integer[] i: p.pieceCanMove()){ //Check each move
                            Board b = new Board(); //Copy the board
                            board.copy(b);
                            b.level = board.level + 1;
                            Board.Piece pCopy = b.BoardGetPiece(x,y);
                            pCopy.movePiece(i[0],i[1]); //move the piece
                            if(b.isInCheckmate(!isWhite) && best.p != null){ continue;} //If the move gets you into check, you don't do it (assuming a move has already been found)
                            if(b.isInCheckmate(isWhite)){  //If you can get a checkmate, you take it
                                best.setMove(1000000,pCopy,x,y,i[0],i[1]);
                                return best;
                            }
                            if( depth == 0) { //Base case
                                double thisScore = b.evaluate(isWhite); //Stores lowest evaluation
                                if (thisScore > best.score) {
                                    best.setMove(thisScore, pCopy, x, y, i[0], i[1]);
                                } else if(thisScore == best.score) {
                                    if(StdRandom.uniform(0,10) >= 5){ //RNG
                                        best.setMove(thisScore, pCopy, x, y, i[0], i[1]);
                                    }
                                }
                            } else {
                                double thisScore = -findBestMove(depth - 1, !isWhite, b).score; //Recursion
                                if (thisScore > best.score){
                                    best.setMove(thisScore, pCopy, x, y, i[0], i[1]);
                                }
                            }
                            b = null;
                        }
                    }
                }
            }
        }
        return best;
    }

    /**Takes a turn*/
    public void takeTurn(){
        final int depth = 3; //Indicates the depth of the search...
        if(depth >= 3) { //Displays a thinking message if the computer will take a while
            StdDraw.setPenColor(StdDraw.PINK); //Makes a pink rectangle
            StdDraw.filledRectangle(3.5, 3.5, 1.5, 0.5);
            StdDraw.setPenColor(StdDraw.WHITE); //and a smaller white rectangle on top
            StdDraw.filledRectangle(3.5, 3.5, 1.4, 0.4);
            StdDraw.setPenColor(StdDraw.BLACK);
            StdDraw.setFont(new Font("Times new Roman", 30, 30));
            StdDraw.text(3.5, 3.5, "Thinking");
        }
        Move m = findBestMove(depth,isWhite,board); // Higher depth means exponentially longer runtime
        if(board.BoardGetPiece(m.x1,m.y1) != null){
            gui.captured(board.BoardGetPiece(m.x1,m.y1)); //Displays captured pieces
        }
        board.BoardGetPiece(m.x,m.y).movePiece(m.x1,m.y1); //Move piece
        StdAudio.play("ChessAudio.wav"); //Sound
    }

}