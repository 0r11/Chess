Chess Game
- Use the ChessModel class to run the game.

Known Limitations:
- There is no En Passant implemented. This is because in order to do this, you must look at previous board states.
  - This is something already stored in two player mode, however, it would cause require much more memory to do with the ai
  - So if we implemented en passant, it would cause a de-sync because the ai would treat it differently
  - Otherwise, we would have to rework how we store stuff in memory 
    - currently, the AI checks tens of thousands of boards each move, so storing each one would be very problamatic
- You can castle out of check
  - This is the case because implementation would require recursion, and cause stack overflow error
- Not all the drawing states are fully implemented
  - Currently, the only 3 draw states are
    - Stalemate
    - 3-fold repetition
      - Technically this only checks whether the same board state has been reached 3 times, and not whether the same moves have been done to reach it
    - Only kings are left on the board
  - not implemented
    - Insufficient mating material (hard to implement (you need to use an external table of ))
    - 50 move rule (Not hard to implement, just uncommon and hard to test, so we didn't)

Known features:
- Chess implemented
  - All Pieces can move
  - Most special moves (except en passant)
    - Check, castle, promotion, pawn double jump
- sounds & graphics
  - Board displayed
    - Code adapted from Domineering lab
  - Menu (ai or pvp)
  - end game notifications
  - captured pieces displayed
  - possible moves
- AI to play with
  - Starts as a random color
  - Looks 3 moves ahead 
    - (Change to adjust runtime and difficulty of AI. THIS IS A BIG O OF LIKE 40^N... )
  - Basically just brute forcing
  - Evaluates the board through the position, and the pieces on it
    - Evaluation adapted from https://www.chess.com/forum/view/chess-variants/relative-values-of-squares-files-ranks-and-layers-of-the-chessboard
  - Semi-randomly choose the best move
- Can end the game with 
  - Drawing
    - See above for more information
  - Checkmate
    - Through a brute force checking of all possible moves

Other non-essential unimplemented features (we didn't really have time for these):
- Ability to restart the game 
  - Not hard to do, we just did other stuff
- Ability to pre-move against the AI
  - This would require a restructuring of our code... also would not word well in two player mode
- Alpha Beta pruning
  - Would improve the AI's run speed, but it would require us to learn how to use hash codes or something...
- Other visual features
  - Rotating the board every move
  - Highlighting the last move
- Ability to adjust AI search depth without editing the program directly

How would we do it differently:
- If we were to code this again, we would probably try developing the piece class as an interface instead.
  - The main reason we didn't do this, was because we didn't know about interfaces until we had already implemented the piece class
- Use the same instances of a piece on different boards
  - Could decrease strain on memory
  - Not currently possible without restructuring entire program